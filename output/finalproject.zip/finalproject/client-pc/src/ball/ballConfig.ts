export const BALL_CONFIG = {
  scale: {
    metersPerWorldUnit: 1,
    physicalRadiusMeters: 0.0335,
    visualScaleMultiplier: 4.75,
    maximumVisualScaleMultiplier: 4.8,
    minimumReadablePixelDiameter: 16,
    measuredRacketHeadWorldWidth: 1.2281404495239258,
    measuredRacketHeadWorldHeight: 1.6398126983642578
  },
  camera: {
    fovDegrees: 50,
    position: [0, 5.2, 13.6],
    // Compose the court slightly left so the trainer HUD occupies right-side margin instead of the singles court.
    target: [0.9, 1.3, 0.8],
    near: 0.1,
    far: 100
  },
  courtHeight: 0.07,
  gravity: -9.81,
  bounceRestitution: 0.68,
  returnedBounceRestitution: 0.58,
  groundFriction: 0.94,
  airDrag: 0.018,
  physicsStepSeconds: 1 / 120,
  maximumPhysicsSubsteps: 12,
  maximumFrameDeltaSeconds: 0.1,
  maximumStepSeconds: 1 / 120,
  maximumFlightMs: 6500,
  stationarySpeed: 0.18,
  bounds: { x: 9, y: 12, zBehindPlayer: 7.5, zFar: -13 },
  launch: {
    launchPosition: [0, 1.85, -7.5],
    easyForehand: { contactSideOffset: 1.15, contactHeight: 0, depthOffset: 0, bounceTime: 0.646, contactTimeAfterBounce: 0.2 },
    easyBackhand: { contactSideOffset: -1.15, contactHeight: 0, depthOffset: 0, bounceTime: 0.646, contactTimeAfterBounce: 0.2 },
    guaranteedForehand: { contactSideOffset: 1.15, contactHeight: 0.18, depthOffset: 0, bounceDepth: -4.7, bounceTime: 0.696, contactTimeAfterBounce: 0.15 },
    guaranteedBackhand: { contactSideOffset: -1.15, contactHeight: 0.18, depthOffset: 0, bounceDepth: -4.7, bounceTime: 0.696, contactTimeAfterBounce: 0.15 },
    centerPractice: { contactSideOffset: 0, contactHeight: 0, depthOffset: 0, bounceTime: 1.4, contactTimeAfterBounce: 0.9 },
    bounceDepth: -4.35,
    netDepth: -5.5,
    netHeight: 0.914,
    netClearance: 0.28,
    expectedContactSampleFraction: 0.5,
    expectedContactPositionSmoothing: 0.85,
    easyContactPoseLift: 0.382,
    referenceFramesPerSecond: 60,
    speedMultipliers: { slow: 0.86, normal: 1, fast: 1.14 }
  },
  contactZone: { maximumTargetDistance: 0.45, maximumTimeToContactMs: 150 },
  easyAssist: {
    contactEllipseMultiplier: 1.35,
    contactTimingToleranceMs: 250,
    targetRadius: 0.22,
    minimumTargetHeight: 0.35,
    maximumTargetHeight: 2.7,
    secondBounceSafetyMarginMs: 220,
    minimumAngularSpeed: 0.65,
    maximumFaceAngleRadians: 1.55,
    assistedStringBedRadius: 0.35,
    naturalReachDepthOffset: 1,
    contactComfortOffsetLocal: [0, 0, 0],
    stationaryReach: { depthTolerance: 0.18, lateralTolerance: 0.2, verticalTolerance: 0.24 },
    comfortableCore: { depthTolerance: 0.08, lateralTolerance: 0.1, verticalTolerance: 0.12 },
    realAttemptCorrectionWorld: {
      lateralMagnitude: 0.2702882277175593,
      vertical: -1.180254966995514,
      depth: -0.049179246641621
    }
  },
  collision: {
    headCenterLocal: [0, 245, 0],
    halfWidthLocal: 51,
    halfHeightLocal: 68,
    thicknessLocal: 5,
    contactEventToleranceMs: 130,
    minimumStrokeSpeed: 4.8,
    maximumFaceAngleRadians: 1.45,
    assistScale: { off: 1, prototype: 1.08, easy: 1.35 },
    movingRacketToleranceLocal: { off: 0, prototype: 2.5, easy: 5 }
  },
  easyTrajectoryAssist: {
    enabled: false,
    startAfterBounce: true,
    maxAcceleration: 3,
    positionGain: 2.4,
    velocityGain: 1.1,
    maxCorrectionAngle: 0.13962634015954636,
    stopDistance: 0.025,
    stopBeforeContactMs: 120
  },
  easySwingIntent: {
    stationaryAngularCeiling: 0.8,
    stationaryAccelerationCeiling: 1.6,
    minimumAngularSpeed: 0.9,
    minimumAcceleration: 1.6,
    minimumForwardScore: 0.09,
    minimumPreparationScore: 0.45,
    fullSwingAngularSpeed: 4.0,
    fullSwingAcceleration: 8.0,
    fullSwingForwardScore: 0.42,
    fullSwingPreparationScore: 0.65,
    minimumConfidence: 0.35,
    maximumFaceAngleRadians: 1.55,
    activeWindowMs: 760
  },
  playableCalibratedHit: {
    windowBeforeMs: 220,
    windowAfterMs: 180,
    minimumAngularSpeed: 1.2,
    minimumAcceleration: 2.5,
    minimumForwardScore: 0.09,
    maximumFaceAngleRadians: 1.55,
    snapDurationMs: 90,
    minimumActiveSwingMs: 24,
    // 0.85 m is the measured half-diagonal of the string bed. The remaining
    // allowance covers the ball, phone-at-handle offset and brief render/network
    // lag. This is still a near-racket gate, not an automatic court-wide hit.
    maximumAssistedContactDistance: 1.40,
    maximumCorrection: { lateral: 0.30, vertical: 0.27, depth: 0.32 },
    practiceResetMs: 1700
  },
  playerAssist: {
    training: {
      windowBeforeMs: 560, windowAfterMs: 520,
      directionAnchorStrength: 0.68,
      minimumAngularSpeed: 0.9, minimumAcceleration: 1.8, minimumForwardDriveScore: 0.09
    },
    realistic: {
      windowBeforeMs: 150, windowAfterMs: 130,
      directionAnchorStrength: 0.28,
      minimumAngularSpeed: 1.2, minimumAcceleration: 2.5, minimumForwardDriveScore: 0.18
    }
  },
  trainingFollowThrough: {
    measurementWindowMs: 260,
    minimumAngularSpeed: 0.9,
    fullAngularSpeed: 7,
    maximumSensorStepSeconds: 0.05,
    sliceForwardAcceleration: 5.2,
    topspinForwardAcceleration: 3.8,
    flatForwardAcceleration: 2.4,
    sliceSpinAcceleration: 46,
    topspinSpinAcceleration: 58
  },
  calibratedSlice: {
    dropDepthPastNetMeters: 2.1,
    deepDepthPastNetMeters: 9.0,
    minimumNetClearanceMeters: 0.16,
    dropSpeedRange: [7.5, 15] as const,
    deepSpeedRange: [9, 20] as const
  },
  sweptContact: {
    historyMs: 140,
    samplesPerFrame: 5,
    overlapLifetimeMs: 160
  },
  response: {
    baseReturnSpeed: 6.5,
    minimumReturnSpeed: 6.5,
    maximumReturnSpeed: 11.2,
    faceInfluence: 0.34,
    courtForwardInfluence: 0.58,
    baseLift: 0.2,
    upwardLift: 0.34,
    maximumSide: 0.22,
    targetInfluence: 0.72,
    constrainedFaceInfluence: 0.12,
    liftInfluence: 0.16,
    sideInfluence: 0.08,
    minimumReturnLift: 3.4,
    maximumReturnLift: 5.6,
    minimumNetClearance: 0.28,
    targetFarCourtBounceDepth: -8.2,
    safeTargets: {
      forehand: [0.65, 1.15, -8.2],
      backhand: [-0.65, 1.15, -8.2],
      center: [0, 1.15, -8.2]
    }
  },
  spin: { magnusCoefficient: 0.022, maximumAcceleration: 7, topspinStrength: 14, sliceStrength: 11 },
  contactRealism: {
    blockAngularSpeed: 0.8,
    strongAngularSpeed: 7,
    weakMotionScore: 0.08,
    minimumIntentConfidence: 0.45,
    offCenterQuality: 0.62,
    mishitFaceAngle: 1.35,
    stringRestitution: 0.58,
    frameRestitution: 0.32,
    blockRestitution: 0.2,
    passiveDamping: 0.68,
    racketEnergyTransfer: 0.75,
    maximumAddedSpeed: 6.5,
    swingLiftInfluence: 2.8,
    minimumSeparationSpeed: 0.65,
    maximumOutgoingSpeed: 24,
    maximumAngularSpeed: 24,
    maximumInferredPivotSpeed: 1.2,
    maximumInferredSwingTranslation: 2.5,
    pivotToSweetSpotMeters: 0.68,
    spinTransfer: 0.36,
    maximumSpinRate: 75,
    flatSpinThreshold: 4,
    easySafetyMinimumForwardSpeed: 2.4,
    easySafetyMinimumLift: 1.25,
    maximumSafetyCorrection: 0.85,
    minimumForwardDirectionQuality: 0.35,
    invalidDirectionDamping: 0.45,
    contactCooldownMs: 120,
    separationDistance: 0.09
  },
  resetDelayMs: 1100
} as const;

export const BALL_DEBUG_DEFAULT = false;
