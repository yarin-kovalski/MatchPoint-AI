﻿# Assignment 3 Exercise 3 Submission

Project: MatchPoint AI / VirtuCourt AI Smart Motion Trainer

Run web/PC POC:
1. Install Node dependencies in the root folder: npm install
2. Install Expo mobile dependencies: cd virtucourt-mobile; npm install
3. From the root folder, run: .\start.ps1

Main deliverables:
- docs/exercise3-competition-research.md
- docs/exercise3-spreadsheet-row.csv
- Node.js Socket.io broker in server/src
- Desktop Three.js client in client-pc/src
- Browser fallback mobile client in client-mobile/src
- Native Expo mobile controller in virtucourt-mobile/App.tsx
